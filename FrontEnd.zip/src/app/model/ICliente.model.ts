export interface ICliente {
  id?: number;
  nome: string;
  cadastro: Date;
  cpf: number;
}
