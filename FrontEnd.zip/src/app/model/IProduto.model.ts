export interface IProduto {
  id?: number;
  nome: string;
  validade: Date;
  preco: number;
}
